'use client'

import { Float, OrbitControls, Sparkles, TorusKnot } from '@react-three/drei'
import { Canvas, useFrame } from '@react-three/fiber'
import { useRef } from 'react'
import type { Mesh } from 'three'

function Core() {
  const mesh = useRef<Mesh>(null)

  useFrame((_, delta) => {
    if (!mesh.current) return
    mesh.current.rotation.x += delta * 0.14
    mesh.current.rotation.y += delta * 0.22
  })

  return (
    <Float speed={1.15} rotationIntensity={0.35} floatIntensity={0.7}>
      <TorusKnot ref={mesh} args={[1.25, 0.34, 160, 32]}>
        <meshPhysicalMaterial
          color="#b7f7df"
          emissive="#146b5b"
          emissiveIntensity={1.8}
          metalness={0.82}
          roughness={0.18}
          clearcoat={1}
          clearcoatRoughness={0.12}
        />
      </TorusKnot>
    </Float>
  )
}

export function IntroScene() {
  return (
    <Canvas
      className="intro-canvas"
      camera={{ position: [0, 0, 6], fov: 42 }}
      dpr={[1, 1.75]}
      gl={{ antialias: true, alpha: true }}
    >
      <ambientLight intensity={0.3} />
      <pointLight position={[3, 3, 4]} intensity={16} color="#c8ffe9" />
      <pointLight position={[-4, -2, 2]} intensity={8} color="#5e63ff" />
      <Core />
      <Sparkles count={140} scale={[8, 6, 5]} size={1.4} speed={0.25} color="#b7f7df" opacity={0.6} />
      <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.18} rotateSpeed={0.2} />
    </Canvas>
  )
}

export default IntroScene


