'use client'

import { useState } from 'react'
import { ArrowUpRight, ChevronDown } from 'lucide-react'
import IntroScene from '@/components/intro-scene'

export default function Page() {
  const [entered, setEntered] = useState(false)

  return (
    <main className={`intro-shell ${entered ? 'is-entered' : ''}`}>
      <div className="intro-grid" aria-hidden="true" />
      <div className="intro-glow intro-glow-one" aria-hidden="true" />
      <div className="intro-glow intro-glow-two" aria-hidden="true" />

      <header className="intro-header">
        <a className="brand-mark" href="#top" aria-label="NOVA home">
          <span className="brand-symbol">N</span>
          <span>NOVA / 01</span>
        </a>
        <div className="header-status"><span className="status-dot" /> SYSTEM ONLINE</div>
      </header>

      <section id="top" className="intro-content" aria-labelledby="intro-title">
        <div className="eyebrow"><span>001</span><span>IMMERSIVE INTERFACE</span></div>
        <div className="scene-wrap" aria-hidden="true"><IntroScene /></div>
        <div className="intro-copy">
          <p className="kicker">A new dimension is waiting</p>
          <h1 id="intro-title">Enter the<br /><em>unknown.</em></h1>
          <p className="intro-description">A quiet space for bold ideas, digital matter, and everything in between.</p>
          <button className="enter-button" type="button" onClick={() => setEntered(true)} aria-label="Enter Nova">
            <span>{entered ? 'ACCESS GRANTED' : 'ENTER EXPERIENCE'}</span>
            <ArrowUpRight size={17} strokeWidth={1.5} />
          </button>
        </div>
      </section>

      <footer className="intro-footer">
        <span>© 2026 NOVA LABS</span>
        <span className="footer-scroll"><ChevronDown size={16} /> SCROLL TO EXPLORE</span>
        <span>JKT / 06°12&apos;S</span>
      </footer>
    </main>
  )
}


